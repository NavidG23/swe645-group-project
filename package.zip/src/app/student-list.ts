export class StudentList {
    students: string[];
}
